vehicle = 0
shape = 0
timer = 1
stuck = false
turn = 0
velTimer = 0
stuckTimer = 0
turnTimer = 0
vacuumLoop = 0

function init()
    vehicle = FindVehicle("vacuum")
    shape = FindShape("shape")

    vacuumLoop = LoadLoop("MOD/snd/vacuum-loop.ogg")
end

function tick(dt)
    if not GetBool("savegame.mod.power_tutorial.complete") then return end
    if IsShapeBroken(shape) then return end

    if IsHandleValid(vehicle) then
        -- Get the vehicle's transform
        local vehicleTransform = GetVehicleTransform(vehicle)
        local body = GetVehicleBody(vehicle)
        local vel = VecLength(GetBodyVelocity(body))
        
        if vel < 0.3 and not stuck then
            velTimer = velTimer + dt
            if velTimer > 2 then
                stuck = true
                if math.random() > 0.5 then
                    turn = 1
                else
                    turn = -1
                end
            end
        else
            velTimer = 0
        end

        if vel < 0.3 then
            stuckTimer = stuckTimer + dt
            turnTimer = turnTimer + dt
            if stuckTimer > 90 then
                SetString("hud.notification", GetTranslatedStringByKey("VAC_1_STUCK"))
            end
            if turnTimer > 10 then
                turnTimer = 0
                turn = turn * -1
            end
        else
            stuckTimer = 0
            turnTimer = 0
        end

        -- Define the starting point and direction for the raycast
        local startPos = vehicleTransform.pos
        local direction = TransformToParentVec(vehicleTransform, Vec(0, 0, -1)) -- Forward direction
        
        --Paint(startPos, 0.3, "spraycan")

        -- Raycast forward from the vehicle
        QueryRejectVehicle(vehicle)
        local raycastDistance = 1.2 -- Distance in meters to cast the ray
        local hit, dist, normal, shape = QueryRaycast(startPos, direction, raycastDistance)
       
        if hit then
            stuck = true
            if math.random() > 0.5 then
                turn = 1
            else
                turn = -1
            end
        end

        if stuck then
            timer = timer - dt
            if timer < 0 then
                stuck = false
                timer = 1
            end

            local hitPoint = VecAdd(startPos, VecScale(direction, dist))
            DriveVehicle(vehicle, -.8, turn, false)
        else
            DriveVehicle(vehicle, 1, 0, false)
            PlayLoop(vacuumLoop, vehicleTransform.pos, 1)
        end
        --clean()
    end
end

function clean()
    local vehicleTransform = GetVehicleTransform(vehicle)
    -- Define the starting point and direction for the raycast
    local startPos = vehicleTransform.pos
    local direction = TransformToParentVec(vehicleTransform, Vec(0, -1, 0)) -- Down direction
    
    -- Raycast Down from the vehicle
    QueryRejectVehicle(vehicle)
    local raycastDistance = 0.4 -- Distance in meters to cast the ray
    local hit, dist, normal, shape = QueryRaycast(startPos, direction, raycastDistance)

    if hit then
        local hitPoint = VecAdd(startPos, VecScale(direction, dist))
        type, r, g, b, a, entry = GetShapeMaterialAtPosition(shape, hitPoint)
        add = .1
        --PaintRGBA(hitPoint, .3, r+add, g+add, b+add, a, .5)
        Paint(hitPoint, .3)
    end
end