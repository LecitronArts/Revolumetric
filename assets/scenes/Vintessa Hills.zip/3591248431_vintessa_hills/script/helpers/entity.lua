cEntity = {}

function cEntity:SetTagInside(handle, tag, value)
    for n in tag:gmatch'[^;]+' do
        local args = {n}

        local old = GetTagValue(handle, n)
        if old == '' then
            if value then
                args[#args+1] = value
            end
        else
            if value then
                local k, v = value:match"([^=,]+=?)(,?.*)"; v=v~=""and v or nil
                if old:find(k) then
                    args[#args+1] = old:gsub("(,?"..k..")[^,]*(,?)", (v and "%1"..v.."%2" or ""))
                else
                    args[#args+1] = old .. "," .. (k .. (v and v or ""))
                end
            end
        end
        SetTag(handle, unpack(args))
    end
    if GetTagValue(handle, tag) == "" then RemoveTag(handle, tag) end
end

function cEntity:ToggleTag(handle, tag, value)
    local tag, tagvalue = tag:gmatch("([^=]+)=?(.*)")()
    if tagvalue == '' then tagvalue = nil end

    if value then
        if value == false then
            RemoveTag(handle, tag)
        else
            SetTag(handle, tag, tagvalue)
        end
    elseif HasTag(handle, tag) then
        RemoveTag(handle, tag)
    else
        SetTag(handle, tag, tagvalue)
    end
end

function cEntity:GetEntities(type_name, tag, bIsGlobal)
    local t = {}

    for n in type_name:gmatch"%S+" do
        if n == "all" then
            for _, v in pairs(FindBodies(tag, bIsGlobal)) do
                table.insert(t, v)
            end
            for _, v in pairs(FindJoints(tag, bIsGlobal)) do
                table.insert(t, v)
            end
            for _, v in pairs(FindVehicles(tag, bIsGlobal)) do
                table.insert(t, v)
            end
            for _, v in pairs(FindShapes(tag, bIsGlobal)) do
                table.insert(t, v)
            end
            for _, v in pairs(FindTriggers(tag, bIsGlobal)) do
                table.insert(t, v)
            end
            for _, v in pairs(FindLocations(tag, bIsGlobal)) do
                table.insert(t, v)
            end
            for _, v in pairs(FindLights(tag, bIsGlobal)) do
                table.insert(t, v)
            end
            for _, v in pairs(FindScreens(tag, bIsGlobal)) do
                table.insert(t, v)
            end
            if FindEntities then
                for _, v in pairs(FindEntities(tag, bIsGlobal, "script")) do
                    table.insert(t, v)
                end
            end
        elseif n == "body" then
            for _, v in pairs(FindBodies(tag, bIsGlobal)) do
                table.insert(t, v)
            end
        elseif n == "joint" or n == "rope" then
            for _, v in pairs(FindJoints(tag, bIsGlobal)) do
                if n == "joint" or GetJointType(v) == "rope" then
                    table.insert(t, v)
                end
            end
        elseif n == "vehicle" then
            for _, v in pairs(FindVehicles(tag, bIsGlobal)) do
                table.insert(t, v)
            end
        elseif n == "vehicleparent" then
            for _, v in pairs(FindVehicles(tag, bIsGlobal)) do
                table.insert(t, v-1)
            end
        elseif n == "shape" then
            for _, v in pairs(FindShapes(tag, bIsGlobal)) do
                table.insert(t, v)
            end
        elseif n == "trigger" then
            for _, v in pairs(FindTriggers(tag, bIsGlobal)) do
                table.insert(t, v)
            end
        elseif n == "location" then
            for _, v in pairs(FindLocations(tag, bIsGlobal)) do
                table.insert(t, v)
            end
        elseif n == "light" then
            for _, v in pairs(FindLights(tag, bIsGlobal)) do
                table.insert(t, v)
            end
        elseif n == "screen" then
            for _, v in pairs(FindScreens(tag, bIsGlobal)) do
                table.insert(t, v)
            end
        elseif n == "script" and FindEntities then
            for _, v in pairs(FindEntities(tag, bIsGlobal, "script")) do
                table.insert(t, v)
            end
        end
    end

    return t
end

function cEntity:EnqueueDeletion(handle, is_folkrace)
    -- we still want to exit scripts, but outside dlc we can't safely delete them
    is_folkrace = is_folkrace or GetString("game.mod") == "dlc-folkrace"
    if not is_folkrace then return true end

    local path = 'level.marked_for_deletion'
    local oldVal = GetString(path)
    handle = handle or GetScriptId()

    if not oldVal:find('%f[%d]' .. handle .. '%f[%D]') then
        SetString(path, oldVal .. ' ' .. handle)
        SetTag(handle, "marked_for_deletion")
    end
    return true
end

function cEntity:GetVehicleJoints(veh)
    local shapes = GetEntityChildren(veh, "", true, "shape")
    local joints_arr, joints_map = {}, {}
    for i = 1, #shapes do
        local shape = shapes[i]
        local joints = GetShapeJoints(shape)
        for j = 1, #joints do
            local joint = joints[j]
            if not joints_map[joint] then
                joints_arr[#joints_arr+1] = joint
                joints_map[joint] = true
            end
        end
    end
    return joints_arr
end

function cEntity:GetNextEntitiesOfType(handle, find_type, tag, excluding_tag, count)
    local entities = {}
    if not handle or handle == 0 then return entities end

    local handle_type = GetEntityType(handle)
    local is_vehicle = handle_type == "vehicle"
    local i = handle + 1
    while (IsHandleValid(i) and (not is_vehicle or GetEntityType(i) ~= handle_type) and not HasTag(i, "scope_end") and (not count or count>0)) do
        if (not find_type or GetEntityType(i) == find_type)
        and (not tag or HasTag(i, tag))
        and (not excluding_tag or not HasTag(i, excluding_tag))
        then
            table.insert(entities, i)
            count = count and count-1
        end
        i = i + 1
    end

    return entities
end

function cEntity:FindClosestBodyToPos(pos, tag, is_global)
    local bodies = FindBodies(tag, is_global)
    local dist, closest = math.huge, nil
    for i = 1, #bodies do
        local body = bodies[i]
        local body_pos = GetBodyTransform(body).pos
        local this_dist = VecLength(VecSub(pos, body_pos))
        if this_dist < dist then
            closest = body
            dist = this_dist
        end
    end
    return closest, closest ~= nil
end

local min, max = math.min, math.max
function GetVehicleAABB(vehicle, including_wheels)
	local aabbMin = Vec(9999, 9999, 9999)
	local aabbMax = Vec(-9999, -9999, -9999)

	local bodies = GetVehicleBodies(vehicle)
	for j = 1, #bodies do
		local bodyAABBMin, bodyAABBMax = GetBodyBounds(bodies[j])
		for i = 1, 3 do
			aabbMin[i] = min(aabbMin[i], bodyAABBMin[i])
			aabbMax[i] = max(aabbMax[i], bodyAABBMax[i])
		end
	end
    if including_wheels then
        local wheels = GetEntityChildren(vehicle, "", true, "wheel")
        for j = 1, #wheels do
            local shapeAABBMin, shapeAABBMax = GetShapeBounds(wheels[j]+1)
            for i = 1, 3 do
                aabbMin[i] = min(aabbMin[i], shapeAABBMin[i])
                aabbMax[i] = max(aabbMax[i], shapeAABBMax[i])
            end
        end
    end
	return aabbMin, aabbMax
end
