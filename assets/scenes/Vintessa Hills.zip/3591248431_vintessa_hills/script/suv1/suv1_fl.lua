function init()
	vehicle = FindVehicle("suv1") 
	joint = FindJoint("fl")
end

function tick()
	if GetPlayerVehicle() == vehicle then
		if InputDown("1") then
			SetJointMotorTarget(joint, 90, 3)
		else
			SetJointMotorTarget(joint, -90, 3)
		end
	else SetJointMotorTarget(joint, 0, 0, 0)
	end
end


