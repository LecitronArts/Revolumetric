
function init()
	vehicle = FindVehicle("suv1") 
	joint = FindJoint("palanca")
end

function tick()
	if GetPlayerVehicle() == vehicle then
		if InputDown("s") then
			SetJointMotorTarget(joint, -30, 5)
		end
		if InputDown("w") then
			SetJointMotorTarget(joint, 30, 5)
		end
		if InputDown("s") and InputDown("w") then
			SetJointMotorTarget(joint, 0, 5)
		end
	else SetJointMotorTarget(joint, 0, 5)
	end
end


