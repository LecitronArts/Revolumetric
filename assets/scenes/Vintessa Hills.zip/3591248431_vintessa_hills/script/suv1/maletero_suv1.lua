
function init()
	vehicle = FindVehicle("suv1") 
	hinge = FindJoint("ma")
end

function tick()
	if GetPlayerVehicle() == vehicle then
		SetJointMotorTarget(hinge, -110, 3)
	else
		SetJointMotorTarget(hinge, 0, 0, 0)
	end
end

