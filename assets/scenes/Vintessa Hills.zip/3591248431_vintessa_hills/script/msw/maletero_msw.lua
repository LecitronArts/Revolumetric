
function init()
	vehicle = FindVehicle("msw") 
	hinge = FindJoint("ma")
end

function tick()
	if GetPlayerVehicle() == vehicle then
		SetJointMotorTarget(hinge, -110, 3)
	else
		SetJointMotorTarget(hinge, 0, 0, 0)
	end
end

