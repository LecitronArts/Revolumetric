function init()
	vehicle = FindVehicle("msw") 
	joint = FindJoint("rl")
end

function tick()
	if GetPlayerVehicle() == vehicle then
		if InputDown("3") then
			SetJointMotorTarget(joint, 90, 3)
		else
			SetJointMotorTarget(joint, -90, 3)
		end
	else SetJointMotorTarget(joint, 0, 0, 0)
	end
end


