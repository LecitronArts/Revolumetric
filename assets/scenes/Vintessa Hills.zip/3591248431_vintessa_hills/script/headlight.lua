
function init()
	light = FindLight("light")
	light2 = FindLight("light2")
	vehicle = FindVehicle("vehicle") 
	hinge = FindJoint("hinge")
	hinge2 = FindJoint("hinge2")
	SetLightEnabled(light, false)
	SetLightEnabled(light2, false)
end

function tick()
	if IsJointBroken(hinge) == false then
		if GetPlayerVehicle() == vehicle then
			SetJointMotor(hinge, -5)
			SetLightEnabled(light, true)
		else
			SetLightEnabled(light, false)
			SetJointMotor(hinge, 5)
		end
	else
		SetLightEnabled(light, false)
	end
	if IsJointBroken(hinge2) == false then
		if GetPlayerVehicle() == vehicle then
			SetJointMotor(hinge2, -5)
			SetLightEnabled(light2, true)
		else
			SetLightEnabled(light2, false)
			SetJointMotor(hinge2, 5)
		end
	else
		SetLightEnabled(light2, false)
	end
end