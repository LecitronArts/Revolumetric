
function init()
	vehicle = FindVehicle("van") 
	hinge = FindJoint("ca")
end

function tick()
	if GetPlayerVehicle() == vehicle then
		SetJointMotorTarget(hinge, -60, 3)
	else
		SetJointMotorTarget(hinge, 0, 0, 0)
	end
end


