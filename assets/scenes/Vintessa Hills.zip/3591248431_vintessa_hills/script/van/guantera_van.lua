function init()
	vehicle = FindVehicle("van") 
	prismatic = FindJoint("guantera")
end

function tick()
	if GetPlayerVehicle() == vehicle then
		if InputDown("u") then
			SetJointMotorTarget(prismatic, 1.25, 3)
		else
			SetJointMotorTarget(prismatic, -1.25, 3)
		end
	else SetJointMotorTarget(prismatic, 0, 0, 0)
	end
end



