
function init()
	vehicle = FindVehicle("suv2") 
	hinge = FindJoint("ma")
end

function tick()
	if GetPlayerVehicle() == vehicle then
		SetJointMotorTarget(hinge, -145, 3)
	else
		SetJointMotorTarget(hinge, 0, 0, 0)
	end
end

