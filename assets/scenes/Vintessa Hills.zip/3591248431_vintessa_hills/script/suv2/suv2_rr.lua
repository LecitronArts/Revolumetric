function init()
	vehicle = FindVehicle("suv2") 
	joint = FindJoint("rr")
end

function tick()
	if GetPlayerVehicle() == vehicle then
		if InputDown("4") then
			SetJointMotorTarget(joint, 90, 3)
		else
			SetJointMotorTarget(joint, -90, 3)
		end
	else SetJointMotorTarget(joint, 0, 0, 0)
	end
end


