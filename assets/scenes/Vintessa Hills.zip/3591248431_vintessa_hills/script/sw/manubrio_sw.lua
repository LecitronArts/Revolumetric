
function init()
	vehicle = FindVehicle("sw") 
	joint = FindJoint("manubrio")
end

function tick()
	if GetPlayerVehicle() == vehicle then
		if InputDown("d") then
			SetJointMotorTarget(joint, -100, 5)
		else
			SetJointMotorTarget(joint, 0, 5)
		end
		if InputDown("a") then
			SetJointMotorTarget(joint, 100, 5)
		end
		if InputDown("d") and InputDown("a") then
			SetJointMotorTarget(joint, 0, 5)
		end
	else SetJointMotorTarget(joint, 0, 5)
	end
end
