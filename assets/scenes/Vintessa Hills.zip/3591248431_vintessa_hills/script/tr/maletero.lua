
function init()
	vehicle = FindVehicle("tr") 
	hinge = FindJoint("ma")
end

function tick()
	if GetPlayerVehicle() == vehicle then
		SetJointMotorTarget(hinge, -110, 5)
	else
		SetJointMotorTarget(hinge, 0, 0, 0)
	end
end

