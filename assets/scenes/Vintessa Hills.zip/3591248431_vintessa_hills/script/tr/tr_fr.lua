function init()
	vehicle = FindVehicle("tr") 
	joint = FindJoint("fr")
end

function tick()
	if GetPlayerVehicle() == vehicle then
		if InputDown("2") then
			SetJointMotorTarget(joint, 90, 3)
		else
			SetJointMotorTarget(joint, -90, 3)
		end
	else SetJointMotorTarget(joint, 0, 0, 0)
	end
end


